﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto3
{
    public class RepositorioUsuario : IRepositorio 
    {
        IList<Usuario> repositorio = new List<Usuario>();

        public void Agregar(string pCodigo, string pNombreCompleto, string pCorreoElectronico)
        {
            Usuario pUsuario = new Usuario(pCodigo, pNombreCompleto, pCorreoElectronico);
            if (!repositorio.Contains(pUsuario))
            {
                repositorio.Add(pUsuario);
            } 
            else { Console.WriteLine("El usuario ya existe"); }

        }
        public void Actualizar(Usuario pUsuario)
        {
            if (repositorio.Contains(pUsuario))
            {
                repositorio.Remove(pUsuario);
                repositorio.Add(pUsuario);
            }       
            else { Console.WriteLine("No existe el usuario"); }
        }

        public Usuario ObtenerPorCodigo(string pCodigo)
        {
            Usuario resultado = new Usuario(" ", "", " ");
            foreach (Usuario usuario in repositorio)
            {   
                if (usuario.Codigo == pCodigo)
                {
                   resultado = usuario;
                }
            }
            return resultado;
        }

  
        public void Eliminar(string pCodigo)
        {
            Usuario pUsuario = new Usuario(pCodigo);
            if (repositorio.Contains(pUsuario))
            {
                Usuario us = ObtenerPorCodigo(pCodigo);
                repositorio.Remove(us);
            }  
        }

        public IList<Usuario> ObtenerTodos()
        {
            IList<Usuario> lista = repositorio;
            return lista;
        }

        public IList<Usuario> OrdenadoPor(IComparer<Usuario> pComparador)
        {
            IList<Usuario> lista = repositorio;
            lista.OrderBy(a => pComparador);
            return lista;
           
        }

        public override bool Equals(object obj)
        {
            return obj is RepositorioUsuario usuario &&
                   EqualityComparer<IList<Usuario>>.Default.Equals(repositorio, usuario.repositorio);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(repositorio);
        }
    }
}
