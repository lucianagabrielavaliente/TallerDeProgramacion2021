﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto3
{
    public class Usuario : IComparable<Usuario>
    {
        private String iCodigo;
        private String iNombreCompleto;
        private String iCorreoElectronico;

        public Usuario(string iCodigo, string iNombreCompleto, string iCorreoElectronico)
        {
            this.iCodigo = iCodigo;
            this.iNombreCompleto = iNombreCompleto;
            this.iCorreoElectronico = iCorreoElectronico;
        }
        public Usuario(string iCodigo)
        {
            this.iCodigo = iCodigo;
        }

        public String Codigo
        {
            get { return this.iCodigo; }
            set { this.iCodigo = value; }
        }
        public String NombreCompleto
        {
            get { return this.iNombreCompleto; }
            set { this.iNombreCompleto = value; }
        }

        public String CorreoElectronico
        {
            get { return this.iCorreoElectronico; }
            set { this.iCorreoElectronico = value; }
        }

        //Mediante la interface IComparable<T> establezca que el orden por defecto de las instancias de Cliente sea alfabéticamente por código

        public int CompareTo(Usuario otroUsuario)
        {
            return this.iCodigo.CompareTo(otroUsuario.Codigo);
        }

        public override bool Equals(object obj)
        {
            return obj is Usuario usuario &&
                   iCodigo == usuario.iCodigo &&
                   iNombreCompleto == usuario.iNombreCompleto &&
                   iCorreoElectronico == usuario.iCorreoElectronico &&
                   Codigo == usuario.Codigo &&
                   NombreCompleto == usuario.NombreCompleto &&
                   CorreoElectronico == usuario.CorreoElectronico;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(iCodigo);
        }
    }
}
