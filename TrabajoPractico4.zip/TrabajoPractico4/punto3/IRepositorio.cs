﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto3
{
    interface IRepositorio 
    {
        void Agregar(String PCodigo, String pNombreCompleto, String pCorreoElectronico);
        void Actualizar(Usuario pUsuario);
        void Eliminar(String pCodigo);
        IList<Usuario> ObtenerTodos();
        Usuario ObtenerPorCodigo(String pCodigo);
        IList<Usuario> OrdenadoPor(IComparer<Usuario> pComparador);
    }
}
