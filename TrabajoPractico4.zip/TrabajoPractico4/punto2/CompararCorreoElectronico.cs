﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto2
{
    public class CompararCorreoElectronico : IComparer<Usuario>
    {
        public int Compare(Usuario pUsuario1, Usuario pUsuario2)
        {
            int Resultado = pUsuario1.CorreoElectronico.CompareTo(pUsuario2.CorreoElectronico);
            if (Resultado != 0)
                return Resultado;
            else
                return pUsuario1.CompareTo(pUsuario2);
        }
    }
}
