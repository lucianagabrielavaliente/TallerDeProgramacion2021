﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto2
{
    class CompararCodigo : IComparer<Usuario>
    {
 
        public int Compare(Usuario pUsuario1, Usuario pUsuario2)
        {
            int Resultado = pUsuario1.Codigo.CompareTo(pUsuario2.Codigo);
            if (Resultado != 0)
                return Resultado;
            else
                return pUsuario1.CompareTo(pUsuario2);
            // return pUsuario1.Codigo.CompareTo(pUsuario2.Codigo);
        }
    }
}
