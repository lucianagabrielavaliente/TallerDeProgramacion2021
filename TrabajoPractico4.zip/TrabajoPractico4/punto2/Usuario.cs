﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace punto2
{
    public class Usuario : IComparable <Usuario>
    {
        private String iCodigo;
        private String iNombreCompleto;
        private String iCorreoElectronico;

        public Usuario(string iCodigo, string iNombreCompleto, string iCorreoElectronico)
        {
            this.iCodigo = iCodigo;
            this.iNombreCompleto = iNombreCompleto;
            this.iCorreoElectronico = iCorreoElectronico;
        }

        public String Codigo
        {
            get { return this.iCodigo; }
            set { this.iCodigo = value; }
        }
        public String NombreCompleto
        {
            get { return this.iNombreCompleto; }
            set { this.iNombreCompleto = value; }
        }

        public String CorreoElectronico
        {
            get { return this.iCorreoElectronico; }
            set { this.iCorreoElectronico = value; }
        }

        //Mediante la interface IComparable<T> establezca que el orden por defecto de las instancias de Cliente sea alfabéticamente por código

        public int CompareTo(Usuario otroUsuario)
        {
            return this.iCodigo.CompareTo(otroUsuario.Codigo);
        }
    }
}
