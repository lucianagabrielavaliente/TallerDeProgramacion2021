﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto2
{
    public class RepositorioUsuario : IRepositorio
    {
        private Dictionary<string, Usuario> repositorio = new Dictionary<string, Usuario>();

        public void Agregar(string pCodigo, string pNombreCompleto, string pCorreoElectronico)
        {
            Usuario pUsuario = new Usuario(pCodigo, pNombreCompleto, pCorreoElectronico);
            repositorio.Add(pCodigo, pUsuario);
        }
        public void Actualizar(Usuario pUsuario)
        {
            repositorio.Remove(pUsuario.Codigo);
            repositorio.Add(pUsuario.Codigo, pUsuario);
        }
    
        public void Eliminar(string pCodigo)
        {
            if (repositorio.ContainsKey(pCodigo))
            {
                repositorio.Remove(pCodigo);
            }
            else { Console.WriteLine("El usuario que esta intentando eliminar no existe");}
        }

        public Usuario ObtenerPorCodigo(string pCodigo)
        {
            return repositorio[pCodigo];
        }

        public IList<Usuario> ObtenerTodos()
        {
            List<Usuario> lista = repositorio.Values.ToList();
            return lista;
        }

        public IList<Usuario> OrdenadoPor(IComparer<Usuario> pComparador)
        {
            List<Usuario> lista = repositorio.Values.ToList();
            lista.Sort(pComparador);
            return lista;
        }
    }
}
