﻿using System;
using Xunit;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using punto3;

namespace Punto3.Test
{
    public class Repositorio_Tests
    {
        [Fact]
        public void Adding_ToList()
        {

            //ARRANGE
            Usuario usuario1 = new punto3.Usuario("1", "Luciana Valiente", "luciana@gmail.com");

            RepositorioUsuario repositorio = new punto3.RepositorioUsuario();
            //ACT

            repositorio.Agregar(usuario1.Codigo, usuario1.NombreCompleto, usuario1.CorreoElectronico);

            //ASSERT

            Assert.Equal(usuario1, repositorio.ObtenerPorCodigo(usuario1.Codigo));

        }
        [Fact]
        public void Delete_FromList()
        {
            //ARRANGE
            Usuario usuario1 = new punto3.Usuario("1", "Luciana Valiente", "luciana@gmail.com");
            Usuario usuario2 = new punto3.Usuario("2", "Silver MiConejo", "silverblanquito@gmail.com");
            Usuario usuario3 = new punto3.Usuario("3", "Manuelita Tortuga", "manuelita@gmail.com");
            Usuario usuario4 = new punto3.Usuario("4", "Chiquita Cocker Spaniel", "chiquita@gmail.com");
            Usuario usuario5 = new punto3.Usuario("5", "Chiquita Cocker Spaniel", "chiquita@gmail.com");
            RepositorioUsuario repositorio = new punto3.RepositorioUsuario();
            repositorio.Agregar(usuario1.Codigo, usuario1.NombreCompleto, usuario1.CorreoElectronico);
            repositorio.Agregar(usuario2.Codigo, usuario2.NombreCompleto, usuario2.CorreoElectronico);
            repositorio.Agregar(usuario3.Codigo, usuario3.NombreCompleto, usuario3.CorreoElectronico);
            repositorio.Agregar(usuario4.Codigo, usuario4.NombreCompleto, usuario4.CorreoElectronico);
            repositorio.Agregar(usuario5.Codigo, usuario5.NombreCompleto, usuario5.CorreoElectronico);

            //ACT
            repositorio.Eliminar(usuario1.Codigo);
            IList<Usuario> lista2 = new List<Usuario>();
            lista2.Add(usuario2);
            lista2.Add(usuario3);
            lista2.Add(usuario4);
            lista2.Add(usuario5);
            //ASSERT
            Assert.Equal(lista2, repositorio.ObtenerTodos());

        }
        [Fact]
        public void Update_User_FromList()
        {
            //ARRANGE
            Usuario usuario1 = new punto3.Usuario("1", "Luciana Valiente", "luciana@gmail.com");
            Usuario usuario2 = new punto3.Usuario("2", "Silver MiConejo", "silverblanquito@gmail.com");
            Usuario usuario3 = new punto3.Usuario("3", "Manuelita Tortuga", "manuelita@gmail.com");
            Usuario usuario4 = new punto3.Usuario("4", "Chiquita Cocker Spaniel", "chiquita@gmail.com");
            Usuario usuario5 = new punto3.Usuario("5", "Chiquita Cocker Spaniel", "chiquita@gmail.com");
            RepositorioUsuario repositorio = new punto3.RepositorioUsuario();
            repositorio.Agregar(usuario1.Codigo, usuario1.NombreCompleto, usuario1.CorreoElectronico);
            repositorio.Agregar(usuario2.Codigo, usuario2.NombreCompleto, usuario2.CorreoElectronico);
            repositorio.Agregar(usuario3.Codigo, usuario3.NombreCompleto, usuario3.CorreoElectronico);
            repositorio.Agregar(usuario4.Codigo, usuario4.NombreCompleto, usuario4.CorreoElectronico);
            repositorio.Agregar(usuario5.Codigo, usuario5.NombreCompleto, usuario5.CorreoElectronico);
            //ACT
            Usuario pUsuario = new Usuario(usuario5.Codigo, "Chiquita Cocker Spaniel", "chiquita2021@gmail.com");
            repositorio.Actualizar(pUsuario);
            //ASSERT
            Assert.False(usuario5 == repositorio.ObtenerPorCodigo(usuario5.Codigo));
        }

        [Fact]
        public void Find_FromList_FromCode()
        {

            //ARRANGE
            Usuario usuario1 = new punto3.Usuario("1", "Luciana Valiente", "luciana@gmail.com");
            Usuario usuario2 = new punto3.Usuario("2", "Silver MiConejo", "silverblanquito@gmail.com");
            Usuario usuario3 = new punto3.Usuario("3", "Manuelita Tortuga", "manuelita@gmail.com");
            Usuario usuario4 = new punto3.Usuario("4", "Chiquita Cocker Spaniel", "chiquita@gmail.com");
            Usuario usuario5 = new punto3.Usuario("5", "Chiquita Cocker Spaniel", "chiquita@gmail.com");
            RepositorioUsuario repositorio = new punto3.RepositorioUsuario();
            repositorio.Agregar(usuario1.Codigo, usuario1.NombreCompleto, usuario1.CorreoElectronico);
            repositorio.Agregar(usuario2.Codigo, usuario2.NombreCompleto, usuario2.CorreoElectronico);
            repositorio.Agregar(usuario3.Codigo, usuario3.NombreCompleto, usuario3.CorreoElectronico);
            repositorio.Agregar(usuario4.Codigo, usuario4.NombreCompleto, usuario4.CorreoElectronico);
            repositorio.Agregar(usuario5.Codigo, usuario5.NombreCompleto, usuario5.CorreoElectronico);
            //ACT
            Usuario usuario = repositorio.ObtenerPorCodigo(usuario4.Codigo);

            //ASSERT
            Assert.Equal(usuario4, usuario);
        }
        [Fact]
        public void Get_AllList()
        {

            //ARRANGE
            Usuario usuario1 = new punto3.Usuario("1", "Luciana Valiente", "luciana@gmail.com");
            Usuario usuario2 = new punto3.Usuario("2", "Silver MiConejo", "silverblanquito@gmail.com");
            Usuario usuario3 = new punto3.Usuario("3", "Manuelita Tortuga", "manuelita@gmail.com");
            Usuario usuario4 = new punto3.Usuario("4", "Chiquita Cocker Spaniel", "chiquita@gmail.com");
            Usuario usuario5 = new punto3.Usuario("5", "Chiquita Cocker Spaniel", "chiquita@gmail.com");
            RepositorioUsuario repositorio = new punto3.RepositorioUsuario();
            repositorio.Agregar(usuario1.Codigo, usuario1.NombreCompleto, usuario1.CorreoElectronico);
            repositorio.Agregar(usuario2.Codigo, usuario2.NombreCompleto, usuario2.CorreoElectronico);
            repositorio.Agregar(usuario3.Codigo, usuario3.NombreCompleto, usuario3.CorreoElectronico);
            repositorio.Agregar(usuario4.Codigo, usuario4.NombreCompleto, usuario4.CorreoElectronico);
            repositorio.Agregar(usuario5.Codigo, usuario5.NombreCompleto, usuario5.CorreoElectronico);
            //ACT
            IList<Usuario> lista = repositorio.ObtenerTodos();
            IList<Usuario> lista2 = new List<Usuario>();
            lista2.Add(usuario1);
            lista2.Add(usuario2);
            lista2.Add(usuario3);
            lista2.Add(usuario4);
            lista2.Add(usuario5);

            //ASSERT
            Assert.Equal(lista2, lista);
        }
        [Fact]
        public void OrderBy_IComparer()
        {

            //ARRANGE
            Usuario usuario1 = new punto3.Usuario("1", "Luciana Valiente", "luciana@gmail.com");
            Usuario usuario2 = new punto3.Usuario("2", "Silver MiConejo", "silverblanquito@gmail.com");
            Usuario usuario3 = new punto3.Usuario("3", "Manuelita Tortuga", "manuelita@gmail.com");

            RepositorioUsuario repositorio = new punto3.RepositorioUsuario();
            repositorio.Agregar(usuario1.Codigo, usuario1.NombreCompleto, usuario1.CorreoElectronico);
            repositorio.Agregar(usuario2.Codigo, usuario2.NombreCompleto, usuario2.CorreoElectronico);
            repositorio.Agregar(usuario3.Codigo, usuario3.NombreCompleto, usuario3.CorreoElectronico);

            //ACT
            CompararNombreCompleto pComparador = new CompararNombreCompleto();
            IList<Usuario> listaOrdenada = repositorio.OrdenadoPor(pComparador);

            //ASSERT
            List<Usuario> lista = new List<Usuario>();
            lista.Add(usuario1);
            lista.Add(usuario3);
            lista.Add(usuario2);

            Assert.Equal(lista, listaOrdenada);
        }

    }
}