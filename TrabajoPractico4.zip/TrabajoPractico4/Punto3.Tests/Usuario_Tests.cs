using System;
using Xunit;
using punto3;

namespace Punto3.Tests
{
    public class Usuario_Tests
    {
        [Fact]
        public void CompareTo()
        {
            //ARRANGE
            Usuario usuario1 = new punto3.Usuario("1", "Luciana Valiente", "luciana@gmail.com");
            Usuario usuario2 = new punto3.Usuario("2", "Silver MiConejo", "silverblanquito@gmail.com");

            //ACT
            usuario1.CompareTo(usuario2);

            //ASSERT
            Assert.Equal(-1, usuario1.CompareTo(usuario2));
        }
    }
}
