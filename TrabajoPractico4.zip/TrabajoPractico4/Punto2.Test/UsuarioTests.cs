using System;
using Xunit;
using punto2;
using System.Collections.Generic;

namespace punto2.Test
{
    public class UsuarioTests
    {
        [Fact]
        public void CompareTo()
        {
            //ARRANGE
            Usuario usuario1 = new punto2.Usuario("1", "Luciana Valiente", "luciana@gmail.com");
            Usuario usuario2 = new punto2.Usuario("2", "Silver MiConejo", "silverblanquito@gmail.com");

            //ACT
            usuario1.CompareTo(usuario2);

            //ASSERT
            Assert.Equal(-1, usuario1.CompareTo(usuario2));
        }
    }
}
