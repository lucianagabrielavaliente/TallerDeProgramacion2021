﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio4
{
    class EvaluadorCantidadCuotas : IEvaluador
    {
        private int iCantidadMaximaCuotas;

        public EvaluadorCantidadCuotas(int pCantidadMaximaCuotas)
        {
            iCantidadMaximaCuotas = pCantidadMaximaCuotas;
        }

        public bool EsValida(SolicitudPrestamo pSolicitudPrestamo)
        {
            if (pSolicitudPrestamo.CantidadCuotas <= iCantidadMaximaCuotas)
                return true;
            else
                return false;
        }
    }
}
