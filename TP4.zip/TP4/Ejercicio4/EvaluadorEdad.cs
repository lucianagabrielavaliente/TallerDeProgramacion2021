﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio4
{
    class EvaluadorEdad : IEvaluador
    {
        private int iEdadMinima;
        private int iEdadMaxima;

        public EvaluadorEdad(int pEdadMinima, int pEdadMaxima)
        {
            iEdadMinima = pEdadMinima;
            iEdadMaxima = pEdadMaxima;
        }

        public bool EsValida(SolicitudPrestamo pSolicitudPrestamo)
        {
            TimeSpan edad = DateTime.Today.Subtract(pSolicitudPrestamo.Cliente.FechaNacimiento);
            double edadEnDias = edad.TotalDays;
            if ((edadEnDias > iEdadMinima * 365) && (edadEnDias < iEdadMaxima * 365))
                return true;
            else
                return false;
        }
    }
}
