﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio4
{
    public enum TipoCliente
    {
        NoCliente,
        Cliente,
        ClienteGold,
        ClientePlatinum
    }
}
