﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace Ejercicio4
{
    class EvaluadorMonto : IEvaluador
    {
        private double iMontoMaximo;

        public EvaluadorMonto(double pMontoMaximo)
        {
            iMontoMaximo = pMontoMaximo;
        }

        public bool EsValida(SolicitudPrestamo pSolicitud)
        {
            throw new NotImplementedException();
        }

        public bool EsValido(SolicitudPrestamo pSolicitudPrestamo)
        {
            if (pSolicitudPrestamo.Monto <= iMontoMaximo)
                return true;
            else
                return false;
        }
    }
}
