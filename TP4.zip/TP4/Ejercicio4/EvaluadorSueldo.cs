﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio4
{
    class EvaluadorSueldo : IEvaluador
    {
        private double iSueldoMinimo;

        public EvaluadorSueldo(double pSueldoMinimo)
        {
            iSueldoMinimo = pSueldoMinimo;
        }

        public bool EsValida(SolicitudPrestamo pSolicitudPrestamo)
        {
            if (pSolicitudPrestamo.Cliente.Empleo.Sueldo >= iSueldoMinimo)
                return true;
            else
                return false;
        }
    }
}
