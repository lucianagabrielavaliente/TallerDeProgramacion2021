﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio4
{
    interface IEvaluador
    {
        bool EsValida(SolicitudPrestamo pSolicitud);
    }
}
