﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio4
{
    public class ControladorFachada
    {
        private GestorPrestamos iGestor = new GestorPrestamos();

        public bool EsValida(SolicitudPrestamo pSolicitud)
        {
            return iGestor.EsValida(pSolicitud);
        }
    }
}
