﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace Ejercicio4
{
    public class Cliente
    {
        private string iNombre;
        private string iApellido;
        private DateTime iFechaNaciemiento;
        private Empleo iEmpleo;
        private TipoCliente iTipoCliente;

        public Cliente(string pNombre, string pApellido, DateTime pFechaNacimiento, Empleo pEmpleo)
        {
            iNombre = pNombre;
            iApellido = pApellido;
            iFechaNaciemiento = pFechaNacimiento;
            iEmpleo = pEmpleo;
        }

        public string Nombre
        {
            get { return iNombre; }
        }

        public string Apellido
        {
            get { return iApellido; }
        }

        public DateTime FechaNacimiento
        {
            get { return iFechaNaciemiento; }
        }

        public Empleo Empleo
        {
            get { return iEmpleo; }
        }

        public TipoCliente TipoCliente
        {
            get { return iTipoCliente; }
            set { iTipoCliente = value; }
        }
    }
}
