﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio1
{
    public class DivisorPorCeroException : Exception
    {
        public DivisorPorCeroException() { }
    }
}
