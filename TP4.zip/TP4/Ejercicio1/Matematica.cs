﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio1
{
    public class Matematica
    {
        static public double Dividir (int pDividendo, int pDivisor)
        {
            if (pDivisor == 0)
            {
                throw new DivisorPorCeroException();
            }
            else
            {
                return (double)pDividendo/(double)pDivisor;
            }
        }
    }
}
