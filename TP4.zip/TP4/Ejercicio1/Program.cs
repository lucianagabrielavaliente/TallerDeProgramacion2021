﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            ControladorFachada fachada = new ControladorFachada();

            Console.WriteLine("Ingrese el dividendo");
            string dividendo = Console.ReadLine();
            int dividendoConvert = Convert.ToInt32(dividendo);
            Console.WriteLine();

            Console.WriteLine("Ingrese el divisor");
            string divisor = Console.ReadLine();
            int divisorConvert = Convert.ToInt32(divisor);
            Console.WriteLine();

            try
            {
                double resultado = fachada.Dividir(dividendoConvert, divisorConvert);
                Console.WriteLine($"{dividendoConvert}/{divisorConvert}= {resultado:0.0}");
            }
            catch (DivisorPorCeroException)
            {
                Console.WriteLine("Error: no se puede dividir por cero");
            }
            Console.ReadKey();
        }
    }
}
