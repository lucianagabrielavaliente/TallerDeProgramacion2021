﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ejercicio1
{
    public class ControladorFachada
    {
        public double Dividir(int pDividendo, int pDivisor)
        {
            return Matematica.Dividir(pDividendo, pDivisor);
        }

    }
}
